package Entities;

import java.awt.Rectangle;

import States.PlayState;

public class Controller {
	
	//getting numbers from Board from PlayState class
	public static final int VMOVE = PlayState.MOVE + 3;
	public static final int HMOVE = PlayState.SIZE;
	public static final int SIZE = PlayState.SIZE;
	public static int XMAX = PlayState.XMAX;
	public static int YMAX = PlayState.YMAX;
	public static int XMIN = PlayState.XMIN;
	public static int [][] BOARD = PlayState.BOARD;
	
	// moving blocks to the right
	public static void moveRight(Form form) {
		if (form.a.getX() + HMOVE <= XMAX - SIZE && form.b.getX() + HMOVE <= XMAX - SIZE 
			&& form.c.getX() + HMOVE <= XMAX - SIZE && form.d.getX() + HMOVE <= XMAX - SIZE) {
			int movea = BOARD[(int) form.a.getY() / SIZE][(((int) form.a.getX() - XMIN) / SIZE) + 1];
			int moveb = BOARD[(int) form.b.getY() / SIZE][(((int) form.b.getX() - XMIN) / SIZE) + 1];
			int movec = BOARD[(int) form.c.getY() / SIZE][(((int) form.c.getX() - XMIN) / SIZE) + 1];
			int moved = BOARD[(int) form.d.getY() / SIZE][(((int) form.d.getX() - XMIN) / SIZE) + 1];
			// updating coordinates of each block
			if (movea == 0 && movea == moveb && moveb == movec && movec == moved) {
				form.a.setLocation((int) form.a.getX() + HMOVE, (int) form.a.getY());
				form.b.setLocation((int) form.b.getX() + HMOVE, (int) form.b.getY());
				form.c.setLocation((int) form.c.getX() + HMOVE, (int) form.c.getY());
				form.d.setLocation((int) form.d.getX() + HMOVE, (int) form.d.getY());
			}
		}
	}
	// moving blocks to the left
	public static void moveLeft(Form form) {
		if (form.a.getX() - HMOVE >= XMIN && form.b.getX() - HMOVE >= XMIN  
			&& form.c.getX() - HMOVE >= XMIN  && form.d.getX() - HMOVE >= XMIN ) {
			int movea = BOARD[(int) form.a.getY() / SIZE][(((int) form.a.getX() - XMIN) / SIZE) - 1];
			int moveb = BOARD[(int) form.b.getY() / SIZE][(((int) form.b.getX() - XMIN) / SIZE) - 1];
			int movec = BOARD[(int) form.c.getY() / SIZE][(((int) form.c.getX() - XMIN) / SIZE) - 1];
			int moved = BOARD[(int) form.d.getY() / SIZE][(((int) form.d.getX() - XMIN) / SIZE) - 1];
			// updating coordinates of each block
			if (movea == 0 && movea == moveb && moveb == movec && movec == moved) {
				form.a.setLocation((int) form.a.getX() - HMOVE, (int) form.a.getY());
				form.b.setLocation((int) form.b.getX() - HMOVE, (int) form.b.getY());
				form.c.setLocation((int) form.c.getX() - HMOVE, (int) form.c.getY());
				form.d.setLocation((int) form.d.getX() - HMOVE, (int) form.d.getY());
			}
		}
	}
	// moving block down 
	public static void moveDown(Form form) {
		if (form.a.getY() + PlayState.SIZE < YMAX - SIZE && form.b.getY() + PlayState.SIZE < YMAX - SIZE && form.c.getY() + PlayState.SIZE < YMAX - SIZE
				&& form.d.getY() + PlayState.SIZE < YMAX - SIZE) {
			int movea = BOARD[((int) form.a.getY() / SIZE) + 1][(((int) form.a.getX() - XMIN) / SIZE)];
			int moveb = BOARD[((int) form.b.getY() / SIZE) + 1][(((int) form.b.getX() - XMIN) / SIZE)];
			int movec = BOARD[((int) form.c.getY() / SIZE) + 1][(((int) form.c.getX() - XMIN) / SIZE)];
			int moved = BOARD[((int) form.d.getY() / SIZE) + 1][(((int) form.d.getX() - XMIN) / SIZE)];
			// updating coordinates of each block
			if (movea == 0 && movea == moveb && moveb == movec && movec == moved) {

				form.a.setLocation((int) form.a.getX(), (int) form.a.getY() + VMOVE);
				form.b.setLocation((int) form.b.getX(), (int) form.b.getY() + VMOVE);
				form.c.setLocation((int) form.c.getX(), (int) form.c.getY() + VMOVE);
				form.d.setLocation((int) form.d.getX(), (int) form.d.getY() + VMOVE);
			}
		}
	}
	// creating blocks
	public static Form makeRect() {
		// random blocks
		int block = (int)(Math.random() * 100);
		String name;
		Rectangle a = new Rectangle (SIZE, SIZE),
				  b = new Rectangle (SIZE, SIZE),
				  c = new Rectangle (SIZE, SIZE),
				  d = new Rectangle (SIZE, SIZE);
		// j shape
		if (block < 15) {
			a.setLocation((XMAX - XMAX/4) - SIZE, 0);
			b.setLocation((XMAX - XMAX/4) - SIZE, SIZE);
			c.setLocation((XMAX - XMAX/4), SIZE);
			d.setLocation((XMAX - XMAX/4) + SIZE, SIZE);
			name = "j";
		} else if (block < 30) {
			a.setLocation((XMAX - XMAX/4) + SIZE, 0);
			d.setLocation((XMAX - XMAX/4) - SIZE, SIZE);
			c.setLocation((XMAX - XMAX/4), SIZE);
			b.setLocation((XMAX - XMAX/4) + SIZE, SIZE);
			name = "l";
		} else if (block < 45) {
			a.setLocation((XMAX - XMAX/4) - SIZE, 0);
			b.setLocation((XMAX - XMAX/4) - SIZE, SIZE);
			c.setLocation((XMAX - XMAX/4), 0);
			d.setLocation((XMAX - XMAX/4), SIZE);
			name = "o";
		} else if (block < 60) {
			a.setLocation((XMAX - XMAX/4) - SIZE, SIZE);
			b.setLocation((XMAX - XMAX/4), SIZE);
			c.setLocation((XMAX - XMAX/4), 0);
			d.setLocation((XMAX - XMAX/4) + SIZE, 0);
			name = "s";
		} else if (block < 75) {
			a.setLocation((XMAX - XMAX/4) - SIZE, SIZE);
			b.setLocation((XMAX - XMAX/4), SIZE);
			c.setLocation((XMAX - XMAX/4), 0);
			d.setLocation((XMAX - XMAX/4) + SIZE, SIZE);
			name = "t";
		} else if (block < 90) {
			a.setLocation((XMAX - XMAX/4) - SIZE, 0);
			b.setLocation((XMAX - XMAX/4), 0);
			c.setLocation((XMAX - XMAX/4), SIZE);
			d.setLocation((XMAX - XMAX/4) + SIZE, SIZE);
			name = "z";
		} else {
			a.setLocation((XMAX - XMAX/4) - SIZE - SIZE, 0);
			b.setLocation((XMAX - XMAX/4) - SIZE, 0);
			c.setLocation((XMAX - XMAX/4), 0);
			d.setLocation((XMAX - XMAX/4) + SIZE, 0);
			name = "i";
		}
		
		return new Form (a,b,c,d,name);
			
	}
	
}
