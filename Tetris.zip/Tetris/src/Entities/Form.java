package Entities;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import Main.SpriteSheets;

public class Form {

	public Rectangle a;
	public Rectangle b;
	public Rectangle c;
	public Rectangle d;
	BufferedImage colorBlock;
	private int colorType;
	private String name;
	public int form = 1;

	public Form(Rectangle a, Rectangle b, Rectangle c, Rectangle d) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}

	public Form(Rectangle a, Rectangle b, Rectangle c, Rectangle d, String name) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.name = name;

		// sets colors of stones
		switch (name) {
		case "j":
			colorBlock = SpriteSheets.colors.get(1);
			colorType = 1;
			break;
		case "l":
			colorBlock = SpriteSheets.colors.get(2);
			colorType = 2;
			break;
		case "o":
			colorBlock = SpriteSheets.colors.get(3);
			colorType = 3;
			break;
		case "s":
			colorBlock = SpriteSheets.colors.get(4);
			colorType = 4;
			break;
		case "t":
			colorBlock = SpriteSheets.colors.get(5);
			colorType = 5;
			break;
		case "z":
			colorBlock = SpriteSheets.colors.get(6);
			colorType = 6;
			break;
		case "i":
			colorBlock = SpriteSheets.colors.get(7);
			colorType = 7;
			break;

		}

	}
	
	public String getName() {
		return name;
	}
	
	public int getColorType() {
		return colorType;
	}
	
	public BufferedImage getBlock() {
		return colorBlock;
	}
	
	public void changeForm() {
		if (form != 4)
			form++;
		else 
			form = 1;
	}

}
