package Main;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import States.EndState;
import States.GameStates;
import States.MenuState;
import States.PlayState;

public class Handler {
	
	
	private final int MENU = 0;
	private final int PLAY = 1;
	private final int ENDSCREEN = 2;
	
	public static int currentState;
	private List <GameStates> states = new ArrayList<GameStates>();
			
	public Handler () {
		currentState = 1;
		states.add(new MenuState(this));
		states.add(new PlayState(this));
		states.add(new EndState(this));
	}
	
	public void setState(int state) {
		if (currentState != state) {
			currentState = state;
			if (currentState == MENU) states.set(currentState, new MenuState(this));
			if (currentState == PLAY) states.set(currentState, new PlayState(this));
			if (currentState  == ENDSCREEN) states.set(currentState, new EndState(this));
		}
	}
	
	public int getStateNum() {
		return currentState;
	}
	
	public GameStates getStateObj() {
		return states.get(currentState);
	}

	public void tick() {
		states.get(currentState).tick();
	}
	
	public void render (Graphics g) {
		states.get(currentState).render(g);
		
	}
	
	


}
