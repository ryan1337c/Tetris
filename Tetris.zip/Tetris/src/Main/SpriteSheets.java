package Main;

import java.awt.image.BufferedImage;
import java.util.HashMap;

import javax.imageio.ImageIO;

public class SpriteSheets {
	
	public static BufferedImage[][] colorBlocks = load("/Blocks/blocks.png", 27, 27);
	public static HashMap <Integer, BufferedImage> colors = load();
			
		public static BufferedImage[][] load (String add, int w, int h) {
			try {
				BufferedImage spritesheet = ImageIO.read(SpriteSheets.class.getResourceAsStream(add));
				int width = spritesheet.getWidth() / w;
				int height = spritesheet.getHeight() / h;
				BufferedImage [][] ret = new BufferedImage[height][width];
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < width; j++) {
						ret[i][j] = spritesheet.getSubimage(j * w, i * h, w, h);
					}
				}
				return ret;
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	
	public static HashMap<Integer,  BufferedImage> load() {
		HashMap <Integer, BufferedImage> temp = new HashMap<Integer, BufferedImage>();
		temp.put(1, colorBlocks[0][9]);
		temp.put(2, colorBlocks[0][3]);
		temp.put(3, colorBlocks[0][4]);
		temp.put(4, colorBlocks[0][5]);
		temp.put(5, colorBlocks[0][6]);
		temp.put(6, colorBlocks[0][7]);
		temp.put(7, colorBlocks[0][8]);
		return temp;
	}
	
}
