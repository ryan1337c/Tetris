package Main;


import java.awt.event.KeyEvent;

import java.awt.event.KeyListener;
import java.util.LinkedList;

import Entities.Controller;
import States.PlayState;

public class KeyInput implements KeyListener {
	
	private Game game;
	
	public KeyInput (Game handler) {
		this.game = handler;
	}
	
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		// PlayState controls
		if (Handler.currentState == 1) {
			if (key == KeyEvent.VK_RIGHT) Controller.moveRight(PlayState.getCurrentForm());
			if (key == KeyEvent.VK_LEFT) Controller.moveLeft(PlayState.getCurrentForm());
			if (key == KeyEvent.VK_DOWN) Controller.moveDown(PlayState.getCurrentForm());
			if (key == KeyEvent.VK_UP) PlayState.moveTurn(PlayState.getCurrentForm());
		}
		
		// MenuState controls
		
		
		// EndState controls
	}
	
	public void keyReleased (KeyEvent e) {
		int key = e.getKeyCode();
		
		// PlayState controls

		
		// MenuState controls
		
		
		// EndState controls
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
