package States;

import java.awt.Graphics;

import java.awt.event.KeyEvent;
import java.util.LinkedList;
import Main.Handler;

public class MenuState extends GameStates {
	
	public MenuState(Handler handler) {
		
	}

	@Override
	public void tick() {
		
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}
}
