package States;

import java.awt.Graphics;

import java.awt.event.KeyEvent;
import java.util.LinkedList;

import Main.Handler;
import TileMap.Background;

public abstract class GameStates {
	
	protected Background bg;
	
	protected Handler handler;
	
	protected double x;
	
	protected double y;
	
	protected double scale;
	
	public abstract void tick();
	
	public abstract void render(Graphics g);
	
}
