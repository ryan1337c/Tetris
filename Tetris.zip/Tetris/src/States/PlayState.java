package States;

import java.awt.Color;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import Main.Game;
import Main.Handler;
import Main.SpriteSheets;
import TileMap.Background;
import TileMap.TileMap;
import Entities.Form;
import Entities.Controller;

public class PlayState extends GameStates {

	// TileMap
	private TileMap tileMap;

	// Variables
	public static final int MOVE = 2;
	public static final int SIZE = 27;
	public static int XMAX = SIZE * 24;
	public static int XMIN = SIZE * 12;
	public static int YMAX = SIZE * 26;
	public static int[][] BOARD = new int[(YMAX / SIZE)][XMAX / SIZE - 12];
	private static Form object;
	private static int linesNo = 0;
	public static int scoreCount;
	private long lastTime;
	private static boolean curBlock;

	// label attributes
	private Color scoreColor;
	private Font font;

	public PlayState(Handler handler) {

		// init
		tileMap = new TileMap(SIZE);
		tileMap.loadTiles("/Blocks/blocks.png");
		tileMap.loadMap("/Map/map1.txt");
		bg = new Background("Resources/Backgrounds/bg4.gif", 1130, 720);

		// filling board with zero
		for (int row = 0; row < BOARD.length; row++) {
			for (int col = 0; col < BOARD[0].length; col++) {
				BOARD[row][col] = 0;
			}
		}

		// Creating score text
		scoreColor = new Color(255, 105, 180);
		font = new Font("Century Gothic", Font.PLAIN, 20);

		// creates first block
		object = Controller.makeRect();
	}

	@Override
	public void tick() {
		// create new blocks
		if (curBlock) {
			object = Controller.makeRect();
			curBlock = false;
		}
		
		moveDown(object);
		// checks if game over
		if (object.a.getY() == 0 || object.b.getY() == 0 || object.c.getY() == 0 || object.d.getY() == 0) {
			System.exit(0);
			handler.setState(2);
		}
		
		// remove rows if full
		int rowToRemove = 0;
		for (int row = 0; row < BOARD.length; row ++) {
			int colCount = 0;
			for (int col = 0; col < BOARD[0].length; col++) {
				if (BOARD[row][col] != 0) colCount++;
			}
			if (colCount == BOARD[0].length) 
				removeRow(rowToRemove);
			rowToRemove++;
			
		}
	}

	@Override
	public void render(Graphics g) {
		bg.render(g);
		tileMap.render(g);

		g.setColor(scoreColor);
		g.setFont(font);
		g.drawString("Score: " + scoreCount, SIZE * 27, 50);

		// renders blocks excluding current block
		for (int i = 0; i < BOARD.length; i++) {
			for (int j = 0; j < BOARD[0].length; j++) {
				if (BOARD[i][j] != 0)
					g.drawImage(SpriteSheets.colors.get(BOARD[i][j]), (int) (XMIN + j * SIZE), (int) (i * SIZE), null);
			}
		}

		// renders current block
		g.drawImage(object.getBlock(), (int) (object.a.getX()), (int) object.a.getY(), null);
		g.drawImage(object.getBlock(), (int) (object.b.getX()), (int) object.b.getY(), null);
		g.drawImage(object.getBlock(), (int) (object.c.getX()), (int) object.c.getY(), null);
		g.drawImage(object.getBlock(), (int) (object.d.getX()), (int) object.d.getY(), null);
	}

	public static Form getCurrentForm() {
		return object;
	}

	public static void updateBoard(Form form) {
		curBlock = true;
		BOARD[(int) form.a.getY() / SIZE][(((int) form.a.getX() - XMIN) / SIZE)] = form.getColorType();
		BOARD[(int) form.b.getY() / SIZE][(((int) form.b.getX() - XMIN) / SIZE)] = form.getColorType();
		BOARD[(int) form.c.getY() / SIZE][(((int) form.c.getX() - XMIN) / SIZE)] = form.getColorType();
		BOARD[(int) form.d.getY() / SIZE][(((int) form.d.getX() - XMIN) / SIZE)] = form.getColorType();
	}

	private void moveDown(Form form) {
		// move down
		if (form.a.getY() + SIZE < YMAX - SIZE && form.b.getY() + SIZE < YMAX - SIZE
				&& form.c.getY() + SIZE < YMAX - SIZE && form.d.getY() + SIZE < YMAX - SIZE) {
			int movea = BOARD[((int) form.a.getY() / SIZE) + 1][(((int) form.a.getX() - XMIN) / SIZE)];
			int moveb = BOARD[((int) form.b.getY() / SIZE) + 1][(((int) form.b.getX() - XMIN) / SIZE)];
			int movec = BOARD[((int) form.c.getY() / SIZE) + 1][(((int) form.c.getX() - XMIN) / SIZE)];
			int moved = BOARD[((int) form.d.getY() / SIZE) + 1][(((int) form.d.getX() - XMIN) / SIZE)];
			if (movea == 0 && movea == moveb && moveb == movec && movec == moved) {
				form.a.setLocation((int) form.a.getX(), (int) form.a.getY() + MOVE);
				form.b.setLocation((int) form.b.getX(), (int) form.b.getY() + MOVE);
				form.c.setLocation((int) form.c.getX(), (int) form.c.getY() + MOVE);
				form.d.setLocation((int) form.d.getX(), (int) form.d.getY() + MOVE);
			}
			// updates Board and score
			else {
				scoreCount++;
				updateBoard(form);
			}
		}
		// updates Board and score
		else {
			scoreCount++;
			updateBoard(form);
		}
		lastTime = System.nanoTime();

	}

	public static void moveTurn(Form form) {
		int f = form.form;
		Rectangle a = form.a;
		Rectangle b = form.b;
		Rectangle c = form.c;
		Rectangle d = form.d;
		// turning clockwise
		switch (form.getName()) {
		case "j":
			// rectangle b is the turning point
			if (f == 1 && cB(a, 1, -1) && cB(c, -1, -1) && cB(d, -2, -2)) {
				MoveRight(form.a);
				MoveDown(form.a);
				MoveDown(form.c);
				MoveLeft(form.c);
				MoveDown(form.d);
				MoveDown(form.d);
				MoveLeft(form.d);
				MoveLeft(form.d);
				form.changeForm();
				break;
			}
			if (f == 2 && cB(a, -1, -1) && cB(c, -1, 1) && cB(d, -2, 2)) {
				MoveLeft(form.a);
				MoveDown(form.a);
				MoveLeft(form.c);
				MoveUp(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 3 && cB(a, -1, 1) && cB(c, 1, 1) && cB(d, 2, 2)) {
				MoveLeft(form.a);
				MoveUp(form.a);
				MoveRight(form.c);
				MoveUp(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 4 && cB(a, 1, 1) && cB(c, 1, -1) && cB(d, 2, -2)) {
				MoveRight(form.a);
				MoveUp(form.a);
				MoveDown(form.c);
				MoveRight(form.c);
				MoveDown(form.d);
				MoveDown(form.d);
				MoveRight(form.d);
				MoveRight(form.d);
				form.changeForm();
				break;
			}
			break;
		case "l":
			if (f == 1 && cB(a, 1, -1) && cB(c, 1, 1) && cB(d, 2, 2)) {
				MoveDown(form.a);
				MoveRight(form.a);
				MoveRight(form.c);
				MoveUp(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 2 && cB(a, -1, -1) && cB(c, 1, -1) && cB(d, 2, -2)) {
				MoveLeft(form.a);
				MoveDown(form.a);
				MoveRight(form.c);
				MoveDown(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				MoveDown(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			if (f == 3 && cB(a, -1, 1) && cB(c, -1, -1) && cB(d, -2, -2)) {
				MoveLeft(form.a);
				MoveUp(form.a);
				MoveLeft(form.c);
				MoveDown(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				MoveDown(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			if (f == 4 && cB(a, 1, 1) && cB(c, -1, 1) && cB(d, -2, 2)) {
				MoveRight(form.a);
				MoveUp(form.a);
				MoveLeft(form.c);
				MoveUp(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			break;
		case "s":
			if (f == 1 && cB(a, 1, 1) && cB(c, 1, -1) && cB(d, 0, -2)) {
				MoveRight(form.a);
				MoveUp(form.a);
				MoveRight(form.c);
				MoveDown(form.c);
				MoveDown(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			if (f == 2 && cB(a, 1, -1) && cB(c, -1, -1) && cB(d, -2, 0)) {
				MoveRight(form.a);
				MoveDown(form.a);
				MoveLeft(form.c);
				MoveDown(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				form.changeForm();
				break;
			}
			if (f == 3 && cB(a, -1, -1) && cB(c, -1, 1) && cB(d, 0, 2)) {
				MoveLeft(form.a);
				MoveDown(form.a);
				MoveLeft(form.c);
				MoveUp(form.c);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 4 && cB(a, -1, 1) && cB(c, 1, 1) && cB(d, 2, 0)) {
				MoveLeft(form.a);
				MoveUp(form.a);
				MoveRight(form.c);
				MoveUp(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				form.changeForm();
				break;
			}
			break;
		case "t":
			if (f == 1 && cB(a, 1, 1) && cB(c, 1, -1) && cB(d, -1, -1)) {
				MoveRight(form.a);
				MoveUp(form.a);
				MoveRight(form.c);
				MoveDown(form.c);
				MoveLeft(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			if (f == 2 && cB(a, 1, -1) && cB(c, -1, -1) && cB(d, -1, 1)) {
				MoveRight(form.a);
				MoveDown(form.a);
				MoveLeft(form.c);
				MoveDown(form.c);
				MoveLeft(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 3 && cB(a, -1, -1) && cB(c, -1, 1) && cB(d, 1, 1)) {
				MoveLeft(form.a);
				MoveDown(form.a);
				MoveLeft(form.c);
				MoveUp(form.c);
				MoveRight(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 4 && cB(a, -1, 1) && cB(c, 1, 1) && cB(d, 1, -1)) {
				MoveLeft(form.a);
				MoveUp(form.a);
				MoveRight(form.c);
				MoveUp(form.c);
				MoveRight(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			break;
		case "z":
			if (f == 1 && cB(a, 1, 1) && cB(c, -1, 1) && cB(d, -2, 0)) {
				MoveRight(form.a);
				MoveUp(form.a);
				MoveLeft(form.c);
				MoveUp(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				form.changeForm();
				break;
			}
			if (f == 2 && cB(a, 1, -1) && cB(c, 1, 1) && cB(d, 0, 2)) {
				MoveRight(form.a);
				MoveDown(form.a);
				MoveRight(form.c);
				MoveUp(form.c);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 3 && cB(a, -1, -1) && cB(c, 1, -1) && cB(d, 2, 0)) {
				MoveLeft(form.a);
				MoveDown(form.a);
				MoveRight(form.c);
				MoveDown(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				form.changeForm();
				break;
			}
			if (f == 4 && cB(a, -1, 1) && cB(c, -1, -1) && cB(d, 0, -2)) {
				MoveLeft(form.a);
				MoveUp(form.a);
				MoveLeft(form.c);
				MoveDown(form.c);
				MoveDown(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			break;
		case "i":
			if (f == 1 && cB(a, 1, 1) && cB(c, -1, -1) && cB(d, -2, -2)) {
				MoveRight(form.a);
				MoveUp(form.a);
				MoveLeft(form.c);
				MoveDown(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				MoveDown(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			if (f == 2 && cB(a, 1, -1) && cB(c, -1, 1) && cB(d, -2, 2)) {
				MoveRight(form.a);
				MoveDown(form.a);
				MoveLeft(form.c);
				MoveUp(form.c);
				MoveLeft(form.d);
				MoveLeft(form.d);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 3 && cB(a, -1, -1) && cB(c, 1, 1) && cB(d, 2, 2)) {
				MoveLeft(form.a);
				MoveDown(form.a);
				MoveRight(form.c);
				MoveUp(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				MoveUp(form.d);
				MoveUp(form.d);
				form.changeForm();
				break;
			}
			if (f == 4 && cB(a, -1, 1) && cB(c, 1, -1) && cB(d, 2, -2)) {
				MoveLeft(form.a);
				MoveUp(form.a);
				MoveRight(form.c);
				MoveDown(form.c);
				MoveRight(form.d);
				MoveRight(form.d);
				MoveDown(form.d);
				MoveDown(form.d);
				form.changeForm();
				break;
			}
			break;
		case "o":
			break;
		}
	}

	private static boolean cB(Rectangle rect, int x, int y) {
		boolean yb = false;
		boolean xb = false;
		if (x >= 0)
			xb = rect.getX() + x * SIZE <= XMAX - SIZE;
		if (x < 0)
			xb = rect.getX() + x * SIZE >= XMIN;
		if (y >= 0)
			yb = rect.getY() - y * SIZE > 0;
		if (y < 0)
			yb = rect.getY() - y * SIZE < YMAX - SIZE;
		return xb && yb && BOARD[((int) rect.getY() / SIZE) - y][(((int) rect.getX() - XMIN) / SIZE) + x] == 0;
	}

	private void removeRow(int row) {
		for (int i = row; i > 0; i--) {
			for (int j = 0; j < BOARD[0].length; j++) {
				BOARD[i][j] = BOARD[i - 1][j];
			}
		}
		for (int j = 0; j < BOARD[0].length; j++) {
			BOARD[0][j] = 0;
		}
	}

	private static void MoveDown(Rectangle rect) {
		if (rect.getY() + SIZE < YMAX - SIZE)
			rect.setLocation((int) rect.getX(), (int) rect.getY() + SIZE);

	}

	private static void MoveRight(Rectangle rect) {
		if (rect.getX() + SIZE <= XMAX - SIZE)
			rect.setLocation((int) rect.getX() + SIZE, (int) rect.getY());
	}

	private static void MoveLeft(Rectangle rect) {
		if (rect.getX() - MOVE + 26 >= XMIN)
			rect.setLocation((int) rect.getX() - SIZE, (int) rect.getY());
	}

	private static void MoveUp(Rectangle rect) {
		if (rect.getY() - MOVE + 26 > 0)
			rect.setLocation((int) rect.getX(), (int) rect.getY() - SIZE);
	}

}
