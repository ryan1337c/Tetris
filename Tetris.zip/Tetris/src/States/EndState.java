package States;

import java.awt.Graphics;

import java.awt.event.KeyEvent;
import java.util.LinkedList;

import Main.Handler;

public class EndState extends GameStates{
	
	public EndState (Handler handler) {
		
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics g) {
		// TODO Auto-generated method stub
		
	}
}
