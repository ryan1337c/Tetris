package TileMap;

import java.awt.image.BufferedImage;

public class Tile {
	public static final int SOLID = 0;
	public static final int NORMAL = 1;
	private BufferedImage subimage;
	private int type;
	
	public Tile (BufferedImage subimage, int type) {
		this.subimage = subimage;
		this.type = type;
	}
	
	public int getType() {
		return type;
	}
	
	public BufferedImage getImage() {
		return subimage;
	}
	
	
}
