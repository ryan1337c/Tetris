package TileMap;

import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import Main.Game;


public class Background {

	private int width, height;
	
	private ImageIcon icon;
	private Image image;
	private Image newImage;
	
	public Background(String path, int width, int height) {
		this.width = width;
		this.height = height;
		try {
			icon = new ImageIcon(path);
			image = icon.getImage();
			// Re-scaling image to fit the screen
			newImage = image.getScaledInstance(this.width, this.height, Image.SCALE_DEFAULT);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void render(Graphics g) {
		g.drawImage(newImage, 0, 0, null);
	}
	
	
	
	
	

}
